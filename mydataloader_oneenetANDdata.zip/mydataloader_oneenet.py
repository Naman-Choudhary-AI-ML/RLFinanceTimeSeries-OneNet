from datetime import datetime
import numpy as np
import os
import torch
from torch.utils.data import Dataset, DataLoader

class DataloaderFinance(Dataset):
    def __init__(self, data_path, tra_date, val_date, tes_date, seq=2,date_format='%Y-%m-%d', DEVICE = 'cuda', batch_size = 16):
        """
        Input Parameters-
        Data path
        Training date
        Validation date
        Test date (Should I create a separate class for loading train and val as one and test separately)
        DEVICE
        Batch size (batch counts number of dates)
        seq - Not sure, don't change
        
        """
        self.batch_size = batch_size
        self.DEVICE = DEVICE


        # LOAD THE DATES
        fnames = [fname for fname in os.listdir(data_path) if
              os.path.isfile(os.path.join(data_path, fname))]
        print(len(fnames), ' tickers selected')
        self.fnames = len(fnames)

        trading_dates = np.genfromtxt(
            os.path.join(data_path, '..', 'trading_dates.csv'), dtype=str,
            delimiter=',', skip_header=True
        )
        print(len(trading_dates), 'trading dates:')

        trade_date_start = trading_dates[0]
        trade_date_end = trading_dates[-1]
        print('trading start to end dates', trade_date_start, trade_date_end)

        # LOAD THE DATA FROM CSV

        data_EOD = []
        print('number of files- ', len(fnames))
        for index, fname in enumerate(fnames):
            # print(fname)
            single_EOD = np.genfromtxt(
                os.path.join(data_path, fname), dtype=float, delimiter=',',
                skip_header=1
            )
            if index == 0:
                print(single_EOD[:].shape)
            concat = []
            for date in single_EOD:
                concat.append(date[1:-1])

            data_EOD.append(np.vstack(concat))

        print('length', len(data_EOD))
        print('shape', len(data_EOD[0]))
        fea_dim = data_EOD[0].shape[1]
        print('number of features is- ', fea_dim)
        self.EOD_data = data_EOD
        

        # transform the trading dates into a dictionary with index, at the same
        # time, transform the indices into a dictionary with weekdays
        dates_index = {}
        # indices_weekday = {}
        data_wd = np.zeros([len(trading_dates), 5], dtype=float)
        wd_encodings = np.identity(5, dtype=float)
        for index, date in enumerate(trading_dates):
            dates_index[date] = index
            # indices_weekday[index] = datetime.strptime(date, date_format).weekday()
            data_wd[index] = wd_encodings[datetime.strptime(date, date_format).weekday()]

        self.tra_ind = dates_index[tra_date]
        self.val_ind = dates_index[val_date]
        self.tes_ind = dates_index[tes_date]
        print(self.tra_ind, self.val_ind, self.tes_ind)

        # count training, validation, and testing instances
        tra_num = 0
        val_num = 0
        tes_num = 0
        # training
        for date_ind in range(self.tra_ind, self.val_ind):
            # filter out instances without length enough history
            if date_ind < seq:
                continue
            for tic_ind in range(len(fnames)):
                tra_num += 1
        print(tra_num, ' training instances')

        # validation
        for date_ind in range(self.val_ind, self.tes_ind):
            # filter out instances without length enough history
            if date_ind < seq:
                continue
            for tic_ind in range(len(fnames)):
                val_num += 1
        print(val_num, ' validation instances')

        # testing
        for date_ind in range(self.tes_ind, len(trading_dates)):
            # filter out instances without length enough history
            if date_ind < seq:
                continue
            for tic_ind in range(len(fnames)):
                tes_num += 1
        print(tes_num, ' testing instances')

        self.num_train_batches =  self.tra_ind // (self.batch_size)
        self.num_val_batches =  self.val_ind // (self.batch_size)
        self.num_test_batches =  self.tes_ind // (self.batch_size)
        print('num of training batches', self.num_train_batches)


        
    def __len__(self):
        return self.num_val_batches * self.fnames #NOT SURE IF i SHOULD CHANGE THIS, DEPENDS ON HOW ONENET TAKES IT
    


    def get_train_index(self):
        return np.arange(self.tra_ind)
        

    def __getitem__(self, index):
        if index >= len(self):
            raise IndexError("Index out of range.")

        start_idx = index * self.batch_size
        end_idx = min(start_idx + self.batch_size, len(self.EOD_data))
        data_batch = self.EOD_data[start_idx:end_idx]

        return torch.tensor(data_batch).to(self.DEVICE)

    def get_validation_data(self):
        val_batches = []
        for date_ind in range(self.tra_ind, self.tra_ind + self.num_val_batches):
            val_batches.append(self.EOD_data[date_ind])
        
        return torch.tensor(val_batches).to(self.DEVICE)

    def get_test_data(self):
        tes_batches = []
        for date_ind in range(self.val_ind, self.val_ind + self.num_val_batches):
            tes_batches.append(self.EOD_data[date_ind])

        return torch.tensor(tes_batches).to(self.DEVICE)
    



dl = DataloaderFinance(
    data_path     = 'data\stocknet-dataset\price\oraw',
    batch_size  = 8,
    tra_date = '2014-01-02', val_date = '2015-08-03',tes_date = '2015-10-01',
    DEVICE = 'cpu',
    # Input Extra parameters here if needed
)

# inputs, targets = next(iter(dl))
# print(inputs.shape, targets.shape)

for x, y in dl:
    print(x.type())
    break